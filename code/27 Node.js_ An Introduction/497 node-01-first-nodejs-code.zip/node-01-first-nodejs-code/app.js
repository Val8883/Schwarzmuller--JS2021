const userName = 'Max';

console.log(`Hi ${userName}!`);