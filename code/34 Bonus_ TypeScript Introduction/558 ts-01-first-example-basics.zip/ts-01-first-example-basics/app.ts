function add(a: number, b: number) {
  return a + b;
}

const result = add(5, 3);

console.log(result);